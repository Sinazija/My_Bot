from .start_and_help import start_bot

#точка входа в проект
if __name__ == 'main':
    start_bot()
    